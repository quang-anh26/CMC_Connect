﻿# CMC Connect — source đăng nhập / đăng ký

Thư mục trong ZIP giữ nguyên đường dẫn tương đối của repo `CMC_Connect`. Các số dòng bên dưới trỏ tới nội dung gốc trong từng file (các file được chép nguyên trạng).

Đây là gói trích xuất source theo chức năng, không phải bản frontend/backend đầy đủ để chạy độc lập. `App.jsx` còn import các màn hình khác không nằm trong ZIP; cấu hình chạy, dependency, database và `application.yml` vẫn lấy từ repo gốc. ZIP không chứa file cấu hình môi trường hay thông tin bí mật.

## Frontend

| File trong repo | Phần cần xem |
|---|---|
| `frontend/src/pages/LoginPage.jsx` | Dòng 1–151: toàn bộ màn hình và xử lý đăng nhập. |
| `frontend/src/pages/RegisterPage.jsx` | Dòng 1–410: toàn bộ đăng ký. Dòng 100–129 gửi mã email; 131–147 gửi lại; 149–169 xác thực mã; 171–210 tạo tài khoản; 225–261 giao diện bước nhập email; 263–303 giao diện xác thực; 305–404 giao diện tạo tài khoản. |
| `frontend/src/pages/ForgotPasswordPage.jsx` | **Màn hình phụ ngoài đăng nhập/đăng ký**, có trong gói để thấy các phần dùng chung. Dòng 1–434 là trang quên mật khẩu; 239–270 nhập email; 272–312 xác thực mã; 314–428 đặt mật khẩu mới. |
| `frontend/src/components/AuthLayout.jsx` | **File tổng hợp/dùng chung** cho login, register và forgot password. Dòng 57–140 là layout; dòng 58 phân biệt chế độ có bước; 79–110 chọn danh sách bước đăng ký/quên mật khẩu hoặc các tính năng ở màn hình login; 111–126 là thanh tiến trình chỉ hiện khi có bước; phần còn lại dựng header/card dùng chung. |
| `frontend/src/components/OtpInput.jsx` | Dòng 1–94: ô nhập mã 6 số; dùng ở bước xác thực đăng ký và quên mật khẩu, không dùng ở login. |
| `frontend/src/components/AuthIcons.jsx` | Dòng 1–53: nhóm icon dùng trong các màn hình auth. |
| `frontend/src/components/Icons.jsx` | **Catalog icon dùng chung toàn app (512 dòng)**. Auth cần logo `MessengerLogo` (dòng 3), `ChatIcon` (35), `FriendsIcon` (77), `GroupIcon` (117) và các glyph dùng qua `AuthIcons` (helper `Svg` từ dòng 386; nhóm icon user/check/lock/mail bắt đầu quanh dòng 418). Các icon còn lại phục vụ chat, feed, hồ sơ, nhóm và những màn hình khác. |
| `frontend/src/styles/auth.css` | Dòng 1–635: CSS cho layout `.ap-*` của login/register và các màn hình auth liên quan; dòng 583 trở đi là theme sáng. Một số class tài khoản/mã xác thực phục vụ riêng màn hình quên mật khẩu. |
| `frontend/src/styles/design-tokens.css` | Dòng 1–107: biến màu/kích thước được auth CSS dùng chung với app. |
| `frontend/src/context/AuthContext.jsx` | **Logic phiên dùng chung**, không phải một giao diện: dòng 11–26 khôi phục phiên; 28–32 login; 34–37 register; 39–49 lưu token/user; 51–62 logout. |
| `frontend/src/api/authApi.js` | Dòng 5–7 endpoint đăng ký; 9–11 endpoint quên mật khẩu; 12–14 login, refresh và logout. |
| `frontend/src/api/axiosClient.js` | Dòng 1–80: HTTP client chung app, gắn access token và tự refresh khi cần. |
| `frontend/src/api/userApi.js` | Dòng 4 (`me`) được `AuthContext` dùng để khôi phục user; dòng 5–22 là API profile/avatar/search dùng ở màn hình khác. |
| `frontend/src/utils/apiError.js` | Dòng 1–22: đổi lỗi API và lỗi validation thành thông báo tiếng Việt. |
| `frontend/src/App.jsx` | **File tổng hợp định tuyến toàn app**. Dòng 31 là `/login`, 32 là `/register`, 33 là `/forgot-password`; dòng 34 trở đi là admin và các màn hình khác (feed, chat, bạn bè, nhóm, video, sự kiện, hồ sơ…). |

Luồng đăng ký hiện tại gồm ba bước: email sinh viên → mã xác thực → thông tin tài khoản. Trang login riêng, không gộp chung trong `RegisterPage.jsx`; hai trang chỉ chia sẻ `AuthLayout` và auth styles.

## Backend

| File trong repo | Phần cần xem |
|---|---|
| `backend/src/main/java/com/example/messaging/controller/AuthController.java` | **Controller tổng hợp auth**. Dòng 19–33 là 3 endpoint đăng ký; 37–53 là 3 endpoint quên mật khẩu; 57–59 login; 62–69 refresh/logout. Base path `/api/auth` ở dòng 12. |
| `backend/src/main/java/com/example/messaging/service/AuthService.java` | **Service tổng hợp nhiều luồng auth**. Dòng 44–99 gửi/xác thực mã và tạo tài khoản; 101–153 quên/đặt lại mật khẩu; 155–188 login; 190–218 refresh/logout và tạo token. |
| `backend/src/main/java/com/example/messaging/service/EmailVerificationService.java` | **Service dùng chung đăng ký và đặt lại mật khẩu**: mã/token, thời hạn, giới hạn gửi và xác thực; luồng mục đích được phân biệt trong enum `Purpose` quanh dòng 67–78. |
| `backend/src/main/java/com/example/messaging/service/MailService.java` | Gửi email xác thực; cùng service xử lý email cho quên mật khẩu. |
| `backend/src/main/java/com/example/messaging/service/RefreshTokenService.java` | Tạo, kiểm tra và thu hồi refresh token; dùng chung vòng đời phiên đăng nhập. |
| `backend/src/main/java/com/example/messaging/config/SecurityConfig.java` | Cấu hình Spring Security/password encoder/JWT filter cho toàn backend, không chỉ giao diện auth. |
| `backend/src/main/java/com/example/messaging/security/JwtUtil.java` và `JwtAuthenticationFilter.java` | Tạo/đọc access JWT và xác thực các request sau đăng nhập. |
| `backend/src/main/java/com/example/messaging/security/CustomUserDetailsService.java` | Nạp user cho Spring Security khi kiểm tra username/mật khẩu. |
| `backend/src/main/java/com/example/messaging/security/CurrentUser.java` | Annotation lấy user hiện tại, được endpoint logout sử dụng. |
| `backend/src/main/java/com/example/messaging/entity/User.java` | Bản ghi user dùng chung toàn app; thông tin auth gồm username/email/password/role/status, các trường hồ sơ khác cũng nằm trong entity. |
| `backend/src/main/java/com/example/messaging/entity/EmailVerification.java` và `RefreshToken.java` | Entity lưu trạng thái mã xác thực và refresh token. |
| `backend/src/main/java/com/example/messaging/entity/enums/Role.java` và `UserStatus.java` | Vai trò và trạng thái tài khoản. |
| `backend/src/main/java/com/example/messaging/repository/UserRepository.java`, `EmailVerificationRepository.java`, `RefreshTokenRepository.java` | Truy vấn user, mã email và refresh token; `UserRepository` còn có truy vấn dùng ở phần khác của app. |
| `backend/src/main/java/com/example/messaging/dto/auth/` | Request/response cho login (`LoginRequest`, `AuthResponse`), 3 bước đăng ký (`SendCode*`, `VerifyCode*`, `RegisterRequest`), forgot password, và refresh. `ChangePasswordRequest` không nằm trong gói vì thuộc API đổi mật khẩu sau đăng nhập. |
| `backend/src/main/java/com/example/messaging/exception/ApiException.java`, `ErrorResponse.java`, `GlobalExceptionHandler.java` | Lỗi API và định dạng phản hồi lỗi dùng chung backend. |
| `backend/src/main/java/com/example/messaging/util/StudentEmailPolicy.java` | Quy tắc email sinh viên được kiểm tra khi đăng ký. |

## Endpoint chính

- Login: `POST /api/auth/login`
- Đăng ký: `POST /api/auth/register/send-code` → `POST /api/auth/register/verify-code` → `POST /api/auth/register`
- Màn hình phụ quên mật khẩu: `POST /api/auth/forgot-password/send-code` → `POST /api/auth/forgot-password/verify-code` → `POST /api/auth/forgot-password/reset`

Muốn chạy hoặc chỉnh sửa trực tiếp, mở repo gốc rồi dùng các đường dẫn trên; ZIP này gom source liên quan và README chỉ vị trí chính xác, không thay thế project đầy đủ.
