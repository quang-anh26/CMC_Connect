# Diễn đàn học tập - bản đồ file FE/BE

Mục đích: tra cứu file và đoạn mã liên quan đến giao diện Diễn đàn học tập. Đây là bản sao tham khảo; thao tác đóng gói không chỉnh sửa các file gốc.

## Cách đọc
- `source/` chứa bản sao nguyên file. Phần đường dẫn sau `source/` là đường dẫn tương đối trong workspace.
- `shared-excerpts/` chỉ chứa các dòng liên quan được trích từ file dùng chung; mỗi dòng có số dòng gốc. Tên tệp `.forum-excerpt.txt` ghi đường dẫn file nguồn.
- `frontend` là phần giao diện/trình duyệt; `backend` là API, mô hình/truy vấn dữ liệu, schema và test backend.
- Các tệp backend trong gói forum thuộc riêng chức năng diễn đàn; entity/repository là phần dữ liệu/API, không phải HTML/CSS.

## Frontend - file riêng (nguyên file)
- `source/frontend/src/pages/ForumPage.jsx` — component và xử lý các màn forum (danh sách, lọc, chi tiết, tạo chủ đề, chia sẻ tài liệu); nhập CSS tại dòng 18. Bản này có 1054 dòng.
- `source/frontend/src/pages/ForumPage.css` — style riêng forum; 1332 dòng.
- `source/frontend/src/api/forumApi.js` — các lời gọi API `/api/forum`; 42 dòng.

## Frontend - file dùng chung, trích riêng đoạn forum
- `shared-excerpts/frontend/src/App.jsx.forum-excerpt.txt` — dòng 21 import `ForumPage`; dòng 62-75 khai báo route `/forum/...`; phần còn lại của App.jsx là route trang khác.
- `shared-excerpts/frontend/src/pages/MainLayout.jsx.forum-excerpt.txt` — dòng 12-14 nhận diện route forum/chọn shell; dòng 25-28 render layout chung. Dòng 12 chứa nhiều route khác.
- `shared-excerpts/frontend/src/components/AppTopBar.jsx.forum-excerpt.txt` — dòng 231-233 là nút diễn đàn trên top bar dùng chung.
- `shared-excerpts/frontend/src/components/PrimarySidebar.jsx.forum-excerpt.txt` — dòng 17-21 là nhóm link sidebar; riêng dòng 19 là mục Diễn đàn học tập.

## Backend - mã nguồn diễn đàn (nguyên file)
- `source/backend/src/main/java/com/example/messaging/forum/controller/` — `ForumController.java` xử lý taxonomy, chủ đề, trả lời, lưu, báo cáo, danh mục/môn học; `ForumFileController.java` xử lý upload/download và tạo chủ đề kèm tệp.
- `source/backend/src/main/java/com/example/messaging/forum/entity/` — mô hình ForumTopic, ForumCategory, ForumCourse, ForumFaculty, ForumMajor, ForumReply, ForumAttachment, ForumBookmark, ForumReport.
- `source/backend/src/main/java/com/example/messaging/forum/repository/` — repository truy vấn cho dữ liệu diễn đàn.
- `source/backend/src/main/java/com/example/messaging/forum/config/ForumCategoryInitializer.java` — khởi tạo danh mục, khoa, chuyên ngành mặc định.
- `source/backend/src/main/resources/db/forum/` — SQL schema riêng cho forum; không phải file thiết kế giao diện.
- `source/backend/src/test/java/com/example/messaging/forum/controller/` — test riêng cho controller diễn đàn.

## Phạm vi và lưu ý
- ZIP không gồm database, uploads, node_modules, build output hay dữ liệu người dùng.
- Số dòng excerpt là số dòng file gốc tại thời điểm tạo ZIP; có thể dịch chuyển nếu file nguồn thay đổi.
- Không đưa file cấu hình chung vào vì không thấy phần cấu hình riêng cho forum trong cấu hình đã kiểm tra.