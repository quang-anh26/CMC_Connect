import React, { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import { Link, Navigate, useLocation, useNavigate, useParams } from 'react-router-dom'
import Avatar from '../components/Avatar'
import { BookOpenIcon, SearchIcon, TopicIcon } from '../components/Icons'
import {
  bookmarkForumTopic,
  createForumTopicWithAttachment,
  deleteForumTopic,
  downloadForumAttachment,
  getForumTaxonomy,
  getForumTopic,
  getForumTopics,
  replyForumTopic,
  reportForumTopic,
  updateForumTopic,
} from '../api/forumApi'
import { useAuth } from '../context/AuthContext'
import './ForumPage.css'

const PAGE_SIZE = 12
const MAX_FILE_SIZE = 50 * 1024 * 1024
const RESOURCE_TYPES = [
  { value: 'CURRICULUM', label: 'Giáo trình' },
  { value: 'STUDY_MATERIAL', label: 'Tài liệu học tập' },
  { value: 'EXAM', label: 'Đề thi' },
  { value: 'LECTURE', label: 'Bài giảng' },
  { value: 'REFERENCE', label: 'Tài liệu tham khảo' },
]
const TOPIC_TYPES = [
  { value: '', label: 'Tất cả chủ đề' },
  { value: 'QUESTION', label: 'Hỏi đáp' },
  { value: 'DISCUSSION', label: 'Thảo luận' },
  { value: 'PROJECT', label: 'Đồ án / tìm đồng đội' },
  { value: 'EXPERIENCE', label: 'Kinh nghiệm học tập' },
  { value: 'KNOWLEDGE', label: 'Trao đổi kiến thức' },
  { value: 'RESOURCE', label: 'Chia sẻ tài liệu' },
]

function getErrorMessage(error) {
  return error?.response?.data?.message
    || error?.response?.data?.error
    || error?.response?.data?.detail
    || error?.response?.data?.title
    || 'Không thể hoàn thành yêu cầu. Vui lòng thử lại.'
}

function formatDate(value) {
  if (!value) return ''
  const date = new Date(value)
  return Number.isNaN(date.getTime()) ? '' : date.toLocaleString('vi-VN')
}

function typeLabel(value) {
  return TOPIC_TYPES.find((type) => type.value === value)?.label || value
}

function formatFileSize(size) {
  if (!size) return 'Tệp đính kèm'
  return size >= 1024 * 1024
    ? `${(size / (1024 * 1024)).toFixed(1)} MB`
    : `${Math.max(1, Math.round(size / 1024))} KB`
}

function createSubmissionKey() {
  if (globalThis.crypto?.randomUUID) return globalThis.crypto.randomUUID()
  const hex = () => Math.floor(Math.random() * 0x10000).toString(16).padStart(4, '0')
  return `${hex()}${hex()}-${hex()}-4${hex().slice(1)}-${((8 + Math.floor(Math.random() * 4)).toString(16))}${hex().slice(1)}-${hex()}${hex()}${hex()}`
}

function ForumHeader({ title = 'Diễn đàn học tập', description }) {
  return (
    <header className="forum-hero">
      <div className="forum-hero-copy">
        <span className="forum-eyebrow">STUDY FORUM · CMC</span>
        <h1>{title}</h1>
        <p>{description || 'Cùng hỏi đáp, thảo luận và chia sẻ tài liệu trong cộng đồng sinh viên CMC.'}</p>
      </div>
      <div className="forum-hero-actions">
        <Link className="forum-button forum-button-primary" to="/forum/new">
          <span aria-hidden="true">＋</span> Tạo chủ đề
        </Link>
        <Link className="forum-button forum-button-secondary" to="/forum/share-resource">
          Chia sẻ tài liệu
        </Link>
      </div>
    </header>
  )
}

function TopicCard({ topic, saved, onBookmark }) {
  return (
    <article className="forum-topic-card">
      <Avatar
        src={topic.authorAvatar}
        name={topic.authorName}
        size={44}
        className="forum-topic-avatar"
      />
      <div className="forum-topic-content">
        <div className="forum-topic-meta">
          <span className={`forum-type-badge forum-type-${topic.type?.toLowerCase()}`}>
            {typeLabel(topic.type)}
          </span>
          {topic.category && (
            <Link className="forum-topic-category" to={`/forum/categories/${topic.categoryId}`}>
              {topic.category}
            </Link>
          )}
          {topic.faculty && (
            <Link className="forum-topic-category" to={`/forum/faculties/${topic.facultyId}`}>
              {topic.faculty}
            </Link>
          )}
          {topic.major && (
            <Link className="forum-topic-category" to={`/forum/majors/${topic.majorId}`}>
              {topic.major}
            </Link>
          )}
          {topic.course && <span className="forum-topic-course">{topic.course}</span>}
        </div>
        <h3><Link to={`/forum/topics/${topic.id}`}>{topic.title}</Link></h3>
        <p className="forum-topic-excerpt">{topic.content}</p>
        <div className="forum-topic-byline">
          <strong>{topic.authorName}</strong>
          <span aria-hidden="true">·</span>
          <time dateTime={topic.createdAt}>{formatDate(topic.createdAt)}</time>
        </div>
      </div>
      <div className="forum-topic-actions">
        <div className="forum-topic-stats" aria-label="Thống kê chủ đề">
          <span title="Lượt xem"><span aria-hidden="true">◉</span> {topic.viewCount || 0}</span>
          <span title="Câu trả lời"><span aria-hidden="true">↩</span> {topic.replyCount || 0}</span>
        </div>
        <button
          className={`forum-bookmark-button${saved ? ' is-saved' : ''}`}
          type="button"
          onClick={() => onBookmark(topic.id, !saved)}
          aria-pressed={saved}
        >
          {saved ? 'Đã lưu' : 'Lưu'}
        </button>
      </div>
    </article>
  )
}

function ForumSidebar({ categories, topics, onCategorySelect }) {
  const latest = [...topics].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)).slice(0, 4)
  const popular = [...topics].sort((a, b) => (b.viewCount || 0) - (a.viewCount || 0)).slice(0, 4)

  return (
    <aside className="forum-sidebar">
      <section className="forum-sidebar-card">
        <div className="forum-sidebar-heading">
          <h2>Danh mục phổ biến</h2>
          <Link to="/forum/categories">Tất cả</Link>
        </div>
        <div className="forum-sidebar-categories">
          {categories.slice(0, 6).map((category, index) => (
            <button key={category.id} type="button" onClick={() => onCategorySelect(category.id)}>
              <span className="forum-category-number">{String(index + 1).padStart(2, '0')}</span>
              <span>{category.name}</span>
              <span aria-hidden="true">›</span>
            </button>
          ))}
          {!categories.length && <p className="forum-sidebar-empty">Danh mục đang được khởi tạo.</p>}
        </div>
      </section>

      <TopicSidebarCard title="Chủ đề mới nhất" topics={latest} empty="Chưa có chủ đề mới." />
      <TopicSidebarCard title="Được quan tâm" topics={popular} empty="Chưa có chủ đề nổi bật." />

      <section className="forum-sidebar-card forum-guidelines">
        <BookOpenIcon size={20} />
        <h2>Cùng xây dựng cộng đồng tốt</h2>
        <p>Đặt tiêu đề rõ ràng, tôn trọng người học khác và ghi nguồn khi chia sẻ tài liệu.</p>
        <Link to="/forum/rules">Xem hướng dẫn cộng đồng <span aria-hidden="true">→</span></Link>
      </section>
    </aside>
  )
}

function TopicSidebarCard({ title, topics, empty }) {
  return (
    <section className="forum-sidebar-card">
      <h2>{title}</h2>
      {topics.length ? (
        <ul className="forum-sidebar-topic-list">
          {topics.map((topic) => (
            <li key={topic.id}>
              <Link to={`/forum/topics/${topic.id}`}>{topic.title}</Link>
              <span>{topic.replyCount || 0} trả lời · {topic.viewCount || 0} lượt xem</span>
            </li>
          ))}
        </ul>
      ) : <p className="forum-sidebar-empty">{empty}</p>}
    </section>
  )
}

function ForumCategories({ categories, onSelect }) {
  return (
    <section className="forum-category-grid" aria-label="Danh mục diễn đàn">
      {categories.map((category, index) => (
        <button
          className="forum-category-card"
          key={category.id}
          type="button"
          onClick={() => onSelect(category.id)}
        >
          <span className={`forum-category-icon forum-category-icon-${index % 5}`} aria-hidden="true">
            {index === 0 ? <TopicIcon size={20} /> : <BookOpenIcon size={20} />}
          </span>
          <span className="forum-category-card-copy">
            <strong>{category.name}</strong>
            <span>{category.description || 'Trao đổi kiến thức và kinh nghiệm cùng cộng đồng.'}</span>
          </span>
          <span className="forum-category-arrow" aria-hidden="true">↗</span>
        </button>
      ))}
    </section>
  )
}

function ForumFilters({
  q, type, categoryId, facultyId, majorId, sort, categories, faculties, majors, onChange, onSearch,
}) {
  return (
    <form className="forum-filters" onSubmit={onSearch}>
      <label className="forum-search-input">
        <SearchIcon size={18} />
        <span className="forum-sr-only">Tìm theo tiêu đề hoặc nội dung</span>
        <input
          value={q}
          onChange={(event) => onChange('q', event.target.value)}
          placeholder="Tìm chủ đề, câu hỏi, tài liệu..."
        />
      </label>
      <label className="forum-filter-select">
        <span className="forum-sr-only">Lọc theo danh mục</span>
        <select value={categoryId} onChange={(event) => onChange('categoryId', event.target.value)}>
          <option value="">Tất cả danh mục</option>
          {categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}
        </select>
      </label>
      <label className="forum-filter-select">
        <span className="forum-sr-only">Lọc theo khoa</span>
        <select value={facultyId} onChange={(event) => onChange('facultyId', event.target.value)}>
          <option value="">Tất cả khoa</option>
          {faculties.map((faculty) => <option key={faculty.id} value={faculty.id}>{faculty.name}</option>)}
        </select>
      </label>
      <label className="forum-filter-select">
        <span className="forum-sr-only">Lọc theo chuyên ngành</span>
        <select
          value={majorId}
          onChange={(event) => onChange('majorId', event.target.value)}
          disabled={!facultyId}
        >
          <option value="">{facultyId ? 'Tất cả chuyên ngành' : 'Chọn khoa trước'}</option>
          {majors.filter((major) => String(major.facultyId) === String(facultyId))
            .map((major) => <option key={major.id} value={major.id}>{major.name}</option>)}
        </select>
      </label>
      <label className="forum-filter-select">
        <span className="forum-sr-only">Sắp xếp chủ đề</span>
        <select value={sort} onChange={(event) => onChange('sort', event.target.value)}>
          <option value="newest">Mới nhất</option>
          <option value="popular">Được xem nhiều</option>
        </select>
      </label>
      <button className="forum-button forum-button-primary forum-search-submit" type="submit">Tìm kiếm</button>
      <input type="hidden" name="type" value={type} />
    </form>
  )
}

export default function ForumPage() {
  const location = useLocation()
  const navigate = useNavigate()
  const {
    topicId,
    categoryId: routeCategoryId,
    courseId: routeCourseId,
    facultyId: routeFacultyId,
    majorId: routeMajorId,
  } = useParams()
  const { user } = useAuth()
  const searchParams = useMemo(() => new URLSearchParams(location.search), [location.search])
  const [topics, setTopics] = useState([])
  const [categories, setCategories] = useState([])
  const [courses, setCourses] = useState([])
  const [faculties, setFaculties] = useState([])
  const [majors, setMajors] = useState([])
  const [page, setPage] = useState(0)
  const [totalPages, setTotalPages] = useState(0)
  const [totalElements, setTotalElements] = useState(0)
  const [q, setQ] = useState(searchParams.get('q') || '')
  const [type, setType] = useState(searchParams.get('type') || '')
  const [categoryFilter, setCategoryFilter] = useState(searchParams.get('categoryId') || '')
  const [facultyFilter, setFacultyFilter] = useState(searchParams.get('facultyId') || '')
  const [majorFilter, setMajorFilter] = useState(searchParams.get('majorId') || '')
  const [sort, setSort] = useState(searchParams.get('sort') || 'newest')
  const [loading, setLoading] = useState(false)
  const [detailLoading, setDetailLoading] = useState(false)
  const [error, setError] = useState('')
  const [notice, setNotice] = useState('')
  const [detail, setDetail] = useState(null)
  const [reply, setReply] = useState('')
  const [reportReason, setReportReason] = useState('')
  const [reporting, setReporting] = useState(false)
  const [savedIds, setSavedIds] = useState(() => new Set())
  const [busy, setBusy] = useState(false)
  const [editing, setEditing] = useState(false)
  const [selectedFaculty, setSelectedFaculty] = useState('')
  const [selectedMajor, setSelectedMajor] = useState('')
  const submissionKey = useRef(null)

  const isNew = location.pathname === '/forum/new' || location.pathname === '/forum/share-resource'
  const isResourceForm = location.pathname === '/forum/share-resource'
    || (isNew && searchParams.get('type') === 'RESOURCE')
  const isDetail = Boolean(topicId)
  const isCategoryIndex = location.pathname === '/forum/categories' && !routeCategoryId
  const isCourseIndex = location.pathname === '/forum/courses' && !routeCourseId
  const isRulePage = location.pathname === '/forum/rules'
  const isModerationRoute = location.pathname === '/forum/admin' || location.pathname === '/forum/moderation'
  const activeCategoryId = routeCategoryId || categoryFilter
  const activeCourseId = routeCourseId || ''
  const majorFromRoute = majors.find((major) => String(major.id) === routeMajorId)
  const activeFacultyId = routeFacultyId || facultyFilter || majorFromRoute?.facultyId || ''
  const activeMajorId = routeMajorId || majorFilter

  useEffect(() => {
    setQ(searchParams.get('q') || '')
    setType(searchParams.get('type') || '')
    setCategoryFilter(searchParams.get('categoryId') || '')
    setFacultyFilter(searchParams.get('facultyId') || '')
    setMajorFilter(searchParams.get('majorId') || '')
    setSort(searchParams.get('sort') || 'newest')
    setPage(0)
  }, [searchParams])

  const loadTaxonomy = useCallback(async () => {
    try {
      const taxonomy = await getForumTaxonomy()
      setCategories(taxonomy.categories || [])
      setCourses(taxonomy.courses || [])
      setFaculties(taxonomy.faculties || [])
      setMajors(taxonomy.majors || [])
      setError('')
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    }
  }, [])

  const loadTopics = useCallback(async () => {
    setLoading(true)
    setError('')
    try {
      const data = await getForumTopics({
        q: location.pathname === '/forum/search' ? q.trim() : '',
        type,
        categoryId: activeCategoryId || undefined,
        courseId: activeCourseId || undefined,
        facultyId: activeFacultyId || undefined,
        majorId: activeMajorId || undefined,
        sort,
        page,
        size: PAGE_SIZE,
      })
      setTopics(data.items || [])
      setTotalPages(data.totalPages || 0)
      setTotalElements(data.totalElements || 0)
    } catch (requestError) {
      setTopics([])
      setError(getErrorMessage(requestError))
    } finally {
      setLoading(false)
    }
  }, [activeCategoryId, activeCourseId, activeFacultyId, activeMajorId, location.pathname, page, q, sort, type])

  useEffect(() => {
    loadTaxonomy()
  }, [loadTaxonomy])

  useEffect(() => {
    if (!isNew && !isDetail && !isCategoryIndex && !isCourseIndex && !isRulePage && !isModerationRoute) {
      loadTopics()
    }
  }, [isCategoryIndex, isCourseIndex, isDetail, isModerationRoute, isNew, isRulePage, loadTopics])

  useEffect(() => {
    if (!isDetail) {
      setDetail(null)
      return undefined
    }
    let active = true
    setDetailLoading(true)
    setError('')
    getForumTopic(topicId)
      .then((data) => {
        if (active) setDetail(data)
      })
      .catch((requestError) => {
        if (active) setError(getErrorMessage(requestError))
      })
      .finally(() => {
        if (active) setDetailLoading(false)
      })
    return () => { active = false }
  }, [isDetail, topicId])

  async function handleBookmark(id, saved) {
    setError('')
    try {
      await bookmarkForumTopic(id, saved)
      setSavedIds((current) => {
        const next = new Set(current)
        if (saved) next.add(id)
        else next.delete(id)
        return next
      })
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    }
  }

  function selectCategory(id) {
    setPage(0)
    navigate(`/forum/categories/${id}`)
  }

  function handleFilterChange(field, value) {
    setPage(0)
    if (field === 'q') setQ(value)
    if (field === 'categoryId') {
      setCategoryFilter(value)
      if (routeCategoryId) {
        navigate(value ? `/forum/categories/${value}` : '/forum')
      }
    }
    if (field === 'facultyId') {
      setFacultyFilter(value)
      setMajorFilter('')
      if (routeFacultyId || routeMajorId) navigate(value ? `/forum/faculties/${value}` : '/forum')
    }
    if (field === 'majorId') {
      setMajorFilter(value)
      if (routeMajorId) navigate(value ? `/forum/majors/${value}` : activeFacultyId ? `/forum/faculties/${activeFacultyId}` : '/forum')
    }
    if (field === 'sort') setSort(value)
  }

  function handleSearch(event) {
    event.preventDefault()
    const params = new URLSearchParams()
    if (q.trim()) params.set('q', q.trim())
    if (type) params.set('type', type)
    if (activeCategoryId) params.set('categoryId', activeCategoryId)
    if (activeFacultyId) params.set('facultyId', activeFacultyId)
    if (activeMajorId) params.set('majorId', activeMajorId)
    if (sort !== 'newest') params.set('sort', sort)
    params.set('page', '0')
    navigate(`/forum/search?${params.toString()}`)
  }

  async function handleCreateTopic(event) {
    event.preventDefault()
    setBusy(true)
    setError('')
    const form = new FormData(event.currentTarget)
    const file = form.get('file')
    const topicType = isResourceForm ? 'RESOURCE' : form.get('type')
    if (!form.get('facultyId')) {
      setError('Chọn khoa trước khi đăng bài.')
      setBusy(false)
      return
    }
    if (isResourceForm && (!file || !file.size)) {
      setError('Bài chia sẻ tài liệu bắt buộc phải có tệp đính kèm.')
      setBusy(false)
      return
    }
    if (file?.size > MAX_FILE_SIZE) {
      setError('Tệp đính kèm vượt quá giới hạn 50 MB.')
      setBusy(false)
      return
    }
    try {
      if (!submissionKey.current) {
        submissionKey.current = createSubmissionKey()
      }
      const created = await createForumTopicWithAttachment({
        title: form.get('title').trim(),
        content: form.get('content').trim(),
        type: topicType,
        resourceKind: isResourceForm ? form.get('resourceKind') : null,
        facultyId: form.get('facultyId'),
        majorId: form.get('majorId') || null,
        courseId: isResourceForm ? form.get('courseId') || null : null,
        source: isResourceForm ? form.get('source').trim() || null : null,
      }, file?.size ? file : null, submissionKey.current)
      navigate(`/forum/topics/${created.id}`)
    } catch (requestError) {
      setError(`Bài viết chưa được đăng. ${getErrorMessage(requestError)} Bạn có thể thử lại mà không tạo bài trùng.`)
    } finally {
      setBusy(false)
    }
  }

  async function handleReply(event) {
    event.preventDefault()
    if (!detail || !reply.trim()) return
    setBusy(true)
    setError('')
    try {
      await replyForumTopic(detail.id, reply.trim())
      setReply('')
      setDetail(await getForumTopic(detail.id))
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  async function handleEdit(event) {
    event.preventDefault()
    if (!detail) return
    const form = new FormData(event.currentTarget)
    setBusy(true)
    setError('')
    try {
      const updated = await updateForumTopic(detail.id, {
        title: form.get('title').trim(),
        content: form.get('content').trim(),
        type: form.get('type'),
        resourceKind: detail.resourceKind || null,
        categoryId: form.get('categoryId') || null,
        courseId: form.get('courseId') || null,
        facultyId: detail.facultyId || null,
        majorId: detail.majorId || null,
        source: form.get('source').trim() || null,
      })
      setDetail((current) => ({ ...current, ...updated }))
      setEditing(false)
      setNotice('Chủ đề đã được cập nhật.')
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  async function handleDelete() {
    if (!detail || !window.confirm('Bạn có chắc muốn xóa chủ đề này không?')) return
    setBusy(true)
    setError('')
    try {
      await deleteForumTopic(detail.id)
      navigate('/forum')
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  async function handleReport(event) {
    event.preventDefault()
    if (!detail || !reportReason.trim()) return
    setBusy(true)
    setError('')
    try {
      await reportForumTopic(detail.id, reportReason.trim())
      setReporting(false)
      setReportReason('')
      setNotice('Cảm ơn bạn đã gửi báo cáo. Nội dung sẽ được xem xét.')
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    } finally {
      setBusy(false)
    }
  }

  async function handleDownload(attachment) {
    setError('')
    try {
      const blob = await downloadForumAttachment(attachment.id)
      const url = URL.createObjectURL(blob)
      const anchor = document.createElement('a')
      anchor.href = url
      anchor.download = attachment.name
      document.body.appendChild(anchor)
      anchor.click()
      anchor.remove()
      window.setTimeout(() => URL.revokeObjectURL(url), 1000)
    } catch (requestError) {
      setError(getErrorMessage(requestError))
    }
  }

  if (isModerationRoute) return <Navigate to="/forum" replace />

  const title = routeCategoryId
    ? categories.find((category) => String(category.id) === routeCategoryId)?.name || 'Chuyên mục'
    : routeCourseId
      ? courses.find((course) => String(course.id) === routeCourseId)?.name || 'Môn học'
      : routeFacultyId
        ? faculties.find((faculty) => String(faculty.id) === routeFacultyId)?.name || 'Khoa'
        : routeMajorId
          ? majors.find((major) => String(major.id) === routeMajorId)?.name || 'Chuyên ngành'
          : 'Diễn đàn học tập'

  if (isCourseIndex) {
    return (
      <div className="forum-page">
        <div className="forum-page-inner">
          <nav className="forum-breadcrumb" aria-label="Điều hướng">
            <Link to="/forum">Cộng đồng học tập</Link>
            <span aria-hidden="true">/</span>
            <span>Môn học</span>
          </nav>
          <ForumHeader title="Khám phá theo môn học" description="Tìm chủ đề và tài liệu được chia sẻ theo từng môn học." />
          <section className="forum-panel forum-courses-index">
            <div className="forum-section-heading">
              <h2>Môn học</h2>
              <p>Chọn môn học để xem nội dung liên quan.</p>
            </div>
            <ForumCategories
              categories={courses.map((course) => ({
                id: course.id,
                name: `${course.code} · ${course.name}`,
                description: 'Câu hỏi, thảo luận và tài liệu của môn học.',
              }))}
              onSelect={(id) => navigate(`/forum/courses/${id}`)}
            />
            {!courses.length && <p className="forum-empty-inline">Chưa có môn học trong danh mục.</p>}
          </section>
        </div>
      </div>
    )
  }

  return (
    <div className="forum-page">
      <div className="forum-page-inner">
        <nav className="forum-breadcrumb" aria-label="Điều hướng">
          <Link to="/forum">Cộng đồng học tập</Link>
          <span aria-hidden="true">/</span>
          {isDetail ? <Link to="/forum">Diễn đàn</Link> : <span>{isNew ? (isResourceForm ? 'Chia sẻ tài liệu' : 'Tạo chủ đề') : title}</span>}
          {isDetail && <><span aria-hidden="true">/</span><span>Chi tiết chủ đề</span></>}
        </nav>

        {isNew ? (
          <>
            <ForumHeader
              title={isResourceForm ? 'Chia sẻ tài liệu học tập' : 'Tạo chủ đề mới'}
              description={isResourceForm
                ? 'Chia sẻ giáo trình, bài giảng, đề thi và tài liệu tham khảo cùng cộng đồng.'
                : 'Đặt câu hỏi, thảo luận kiến thức, tìm đồng đội và chia sẻ kinh nghiệm học tập.'}
            />
            <section className="forum-panel forum-editor-panel">
              <div className="forum-section-heading">
                <h2>{isResourceForm ? 'Thông tin tài liệu' : 'Thông tin chủ đề'}</h2>
                <p>{isResourceForm ? 'Tài liệu sẽ được chia sẻ ngay sau khi đăng.' : 'Chủ đề sẽ xuất hiện ngay sau khi đăng.'}</p>
              </div>
              {error && <div className="forum-alert forum-alert-error" role="alert">{error}</div>}
              {notice && <div className="forum-alert forum-alert-success" role="status">{notice}</div>}
              <form className="forum-editor-form" onSubmit={handleCreateTopic}>
                <div className="forum-form-row">
                  {!isResourceForm && (
                    <label className="forum-field">
                      <span>Loại chủ đề</span>
                      <select name="type" defaultValue={searchParams.get('type') || 'QUESTION'}>
                        {TOPIC_TYPES.filter((item) => item.value && item.value !== 'RESOURCE').map((item) => (
                          <option key={item.value} value={item.value}>{item.label}</option>
                        ))}
                      </select>
                    </label>
                  )}
                  {isResourceForm && <input type="hidden" name="type" value="RESOURCE" />}
                  <label className="forum-field">
                    <span>Khoa</span>
                    <select
                      name="facultyId"
                      value={selectedFaculty}
                      required
                      onChange={(event) => {
                        setSelectedFaculty(event.target.value)
                        setSelectedMajor('')
                      }}
                    >
                      <option value="">Chọn khoa</option>
                      {faculties.map((faculty) => (
                        <option key={faculty.id} value={faculty.id}>{faculty.name}</option>
                      ))}
                    </select>
                  </label>
                  <label className="forum-field">
                    <span>Chuyên ngành <small>(không bắt buộc)</small></span>
                    <select
                      name="majorId"
                      value={selectedMajor}
                      disabled={!selectedFaculty}
                      onChange={(event) => setSelectedMajor(event.target.value)}
                    >
                      <option value="">{selectedFaculty ? 'Chọn chuyên ngành' : 'Chọn khoa trước'}</option>
                      {majors.filter((major) => String(major.facultyId) === String(selectedFaculty))
                        .map((major) => <option key={major.id} value={major.id}>{major.name}</option>)}
                      {selectedFaculty && !majors.some((major) => String(major.facultyId) === String(selectedFaculty))
                        && <option value="" disabled>Chưa có chuyên ngành cụ thể</option>}
                    </select>
                  </label>
                  {isResourceForm && (
                    <label className="forum-field">
                      <span>Loại tài liệu</span>
                      <select name="resourceKind" required defaultValue="STUDY_MATERIAL">
                        {RESOURCE_TYPES.map((resourceType) => (
                          <option key={resourceType.value} value={resourceType.value}>{resourceType.label}</option>
                        ))}
                      </select>
                    </label>
                  )}
                </div>
                <label className="forum-field">
                  <span>{isResourceForm ? 'Tên tài liệu' : 'Tiêu đề'}</span>
                  <input
                    name="title"
                    required
                    maxLength={180}
                    placeholder={isResourceForm ? 'Nhập tên giáo trình, đề thi hoặc tài liệu' : 'Tóm tắt câu hỏi hoặc nội dung bạn muốn chia sẻ'}
                  />
                </label>
                <label className="forum-field">
                  <span>{isResourceForm ? 'Mô tả tài liệu' : 'Nội dung'}</span>
                  <textarea
                    name="content"
                    required
                    maxLength={30000}
                    rows={9}
                    placeholder={isResourceForm
                      ? 'Mô tả nội dung, môn học hoặc cách sử dụng tài liệu...'
                      : 'Thêm bối cảnh, nội dung chi tiết và điều bạn đã thử...'}
                  />
                </label>
                {isResourceForm && (
                  <>
                    <label className="forum-field">
                      <span>Môn học <small>(không bắt buộc)</small></span>
                      <select name="courseId" defaultValue="">
                        <option value="">Chọn môn học</option>
                        {courses.map((course) => (
                          <option key={course.id} value={course.id}>{course.code} · {course.name}</option>
                        ))}
                      </select>
                    </label>
                    <label className="forum-field">
                      <span>Nguồn tài liệu</span>
                      <input name="source" maxLength={500} placeholder="Link hoặc thông tin trích dẫn nguồn" />
                    </label>
                  </>
                )}
                <label className="forum-field">
                  <span>Tệp đính kèm {isResourceForm ? '(bắt buộc)' : '(không bắt buộc)'} <small>(PDF, DOC, DOCX, PPT, PPTX, XLS, XLSX, ZIP, MP4 · tối đa 50 MB)</small></span>
                  <input
                    name="file"
                    type="file"
                    required={isResourceForm}
                    accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.zip,.mp4"
                  />
                </label>
                <div className="forum-form-footer">
                  <p>{isResourceForm ? 'Hãy chia sẻ tài liệu bạn có quyền sử dụng và ghi rõ nguồn.' : 'Chọn khoa và chuyên ngành phù hợp để cộng đồng dễ tìm thấy chủ đề.'}</p>
                  <div className="forum-form-actions">
                    <Link className="forum-button forum-button-secondary" to="/forum">Hủy</Link>
                    <button className="forum-button forum-button-primary" type="submit" disabled={busy}>
                      {busy ? 'Đang đăng...' : isResourceForm ? 'Chia sẻ tài liệu' : 'Đăng chủ đề'}
                    </button>
                  </div>
                </div>
              </form>
            </section>
          </>
        ) : isDetail ? (
          <section className="forum-detail-layout">
            <main className="forum-detail-main">
              {detailLoading ? <div className="forum-panel forum-loading">Đang tải chủ đề...</div> : null}
              {error && !detailLoading && <div className="forum-alert forum-alert-error" role="alert">{error}</div>}
              {notice && <div className="forum-alert forum-alert-success" role="status">{notice}</div>}
              {detail && (
                <>
                  <article className="forum-panel forum-detail-card">
                    <div className="forum-detail-topline">
                      <span className={`forum-type-badge forum-type-${detail.type?.toLowerCase()}`}>{typeLabel(detail.type)}</span>
                      {detail.category && <Link to={`/forum/categories/${detail.categoryId}`}>{detail.category}</Link>}
                      {detail.faculty && <Link to={`/forum/faculties/${detail.facultyId}`}>{detail.faculty}</Link>}
                      {detail.major && <Link to={`/forum/majors/${detail.majorId}`}>{detail.major}</Link>}
                      <time dateTime={detail.createdAt}>{formatDate(detail.createdAt)}</time>
                    </div>
                    {detail.resourceKind && (
                      <span className="forum-type-badge forum-type-resource">
                        {RESOURCE_TYPES.find((item) => item.value === detail.resourceKind)?.label || 'Tài liệu học tập'}
                      </span>
                    )}
                    {editing ? (
                      <form className="forum-editor-form forum-edit-form" onSubmit={handleEdit}>
                        <label className="forum-field">
                          <span>Tiêu đề</span>
                          <input name="title" defaultValue={detail.title} required maxLength={180} />
                        </label>
                        <div className="forum-form-row">
                          <label className="forum-field">
                            <span>Loại chủ đề</span>
                            <select name="type" defaultValue={detail.type}>
                              {TOPIC_TYPES.filter((item) => item.value).map((item) => (
                                <option key={item.value} value={item.value}>{item.label}</option>
                              ))}
                            </select>
                          </label>
                          <label className="forum-field">
                            <span>Danh mục</span>
                            <select name="categoryId" defaultValue={detail.categoryId || ''}>
                              <option value="">Chọn danh mục</option>
                              {categories.map((category) => <option key={category.id} value={category.id}>{category.name}</option>)}
                            </select>
                          </label>
                          <label className="forum-field">
                            <span>Môn học</span>
                            <select name="courseId" defaultValue={detail.courseId || ''}>
                              <option value="">Chọn môn học</option>
                              {courses.map((course) => <option key={course.id} value={course.id}>{course.code} · {course.name}</option>)}
                            </select>
                          </label>
                        </div>
                        <label className="forum-field">
                          <span>Nội dung</span>
                          <textarea name="content" defaultValue={detail.content} required maxLength={30000} rows={9} />
                        </label>
                        <label className="forum-field">
                          <span>Nguồn tài liệu</span>
                          <input name="source" defaultValue={detail.source || ''} maxLength={500} />
                        </label>
                        <div className="forum-form-actions">
                          <button className="forum-button forum-button-secondary" type="button" onClick={() => setEditing(false)}>Hủy</button>
                          <button className="forum-button forum-button-primary" type="submit" disabled={busy}>{busy ? 'Đang lưu...' : 'Lưu thay đổi'}</button>
                        </div>
                      </form>
                    ) : (
                      <>
                        <h1 className="forum-detail-title">{detail.title}</h1>
                        <div className="forum-author-line">
                          <Avatar src={detail.authorAvatar} name={detail.authorName} size={42} />
                          <div>
                            <strong>{detail.authorName}</strong>
                            <span>Thành viên cộng đồng · {formatDate(detail.createdAt)}</span>
                          </div>
                          {detail.authorId === user?.userId && (
                            <div className="forum-owner-actions">
                              <button type="button" onClick={() => setEditing(true)}>Chỉnh sửa</button>
                              <button type="button" onClick={handleDelete} disabled={busy}>Xóa</button>
                            </div>
                          )}
                        </div>
                        <div className="forum-detail-content">{detail.content}</div>
                        {detail.source && <p className="forum-source"><strong>Nguồn:</strong> {detail.source}</p>}
                        {!!detail.attachments?.length && (
                          <div className="forum-attachments">
                            <h2>Tệp đính kèm</h2>
                            {detail.attachments.map((attachment) => (
                              <button key={attachment.id} type="button" onClick={() => handleDownload(attachment)}>
                                <span aria-hidden="true">↧</span>
                                <span>{attachment.name}</span>
                                <small>{(attachment.extension || attachment.name.split('.').pop()).toUpperCase()} · {formatFileSize(attachment.size)}</small>
                              </button>
                            ))}
                          </div>
                        )}
                        <div className="forum-detail-toolbar">
                          <button type="button" onClick={() => handleBookmark(detail.id, !savedIds.has(detail.id))}>
                            {savedIds.has(detail.id) ? 'Đã lưu chủ đề' : '☆ Lưu chủ đề'}
                          </button>
                          <span>{detail.viewCount || 0} lượt xem</span>
                          <button type="button" onClick={() => setReporting((current) => !current)}>Báo cáo</button>
                        </div>
                        {reporting && (
                          <form className="forum-report-form" onSubmit={handleReport}>
                            <label className="forum-field">
                              <span>Lý do báo cáo</span>
                              <textarea value={reportReason} onChange={(event) => setReportReason(event.target.value)} required maxLength={500} rows={3} />
                            </label>
                            <button className="forum-button forum-button-secondary" type="submit" disabled={busy}>Gửi báo cáo</button>
                          </form>
                        )}
                      </>
                    )}
                  </article>

                  {!editing && (
                    <section className="forum-panel forum-replies">
                      <div className="forum-section-heading">
                        <h2>Thảo luận <span>{detail.replies?.length || 0}</span></h2>
                        <p>Cùng nhau trao đổi để tìm câu trả lời tốt nhất.</p>
                      </div>
                      <form className="forum-reply-form" onSubmit={handleReply}>
                        <Avatar name={user?.displayName || user?.username} size={38} />
                        <label className="forum-field">
                          <span className="forum-sr-only">Nội dung trả lời</span>
                          <textarea value={reply} onChange={(event) => setReply(event.target.value)} placeholder="Viết câu trả lời hoặc chia sẻ góc nhìn của bạn..." required maxLength={10000} rows={3} />
                        </label>
                        <button className="forum-button forum-button-primary" type="submit" disabled={busy || !reply.trim()}>
                          {busy ? 'Đang gửi...' : 'Gửi trả lời'}
                        </button>
                      </form>
                      <div className="forum-reply-list">
                        {detail.replies?.map((item) => (
                          <article className="forum-reply" key={item.id}>
                            <Avatar src={item.authorAvatar} name={item.author} size={38} />
                            <div>
                              <div className="forum-reply-meta"><strong>{item.author}</strong><time>{formatDate(item.createdAt)}</time></div>
                              <p>{item.content}</p>
                            </div>
                          </article>
                        ))}
                        {!detail.replies?.length && <p className="forum-empty-inline">Chưa có câu trả lời. Hãy bắt đầu cuộc thảo luận.</p>}
                      </div>
                    </section>
                  )}
                </>
              )}
            </main>
            <ForumSidebar categories={categories} topics={[]} onCategorySelect={selectCategory} />
          </section>
        ) : isCategoryIndex ? (
          <>
            <ForumHeader title="Khám phá chuyên mục" description="Tìm đúng không gian để đặt câu hỏi, chia sẻ kiến thức và học cùng nhau." />
            <section className="forum-panel forum-categories-panel">
              <div className="forum-section-heading">
                <h2>Danh mục diễn đàn</h2>
                <p>Chọn một chuyên mục để xem các chủ đề liên quan.</p>
              </div>
              <ForumCategories categories={categories} onSelect={selectCategory} />
              {!categories.length && <p className="forum-empty-inline">Các danh mục đang được khởi tạo. Vui lòng tải lại sau ít phút.</p>}
            </section>
          </>
        ) : isRulePage ? (
          <section className="forum-panel forum-rules">
            <ForumHeader title="Hướng dẫn cộng đồng" description="Một cộng đồng học tập hữu ích bắt đầu từ sự tôn trọng và chia sẻ có trách nhiệm." />
            <h2>Quy định diễn đàn</h2>
            <ul>
              <li>Trao đổi lịch sự, tập trung vào nội dung và tôn trọng sự khác biệt.</li>
              <li>Đặt tiêu đề rõ ràng, cung cấp đủ bối cảnh khi đặt câu hỏi.</li>
              <li>Trích dẫn nguồn và chỉ chia sẻ tài liệu bạn có quyền sử dụng.</li>
              <li>Không đăng thông tin cá nhân, nội dung spam hoặc nội dung vi phạm pháp luật.</li>
            </ul>
            <Link className="forum-button forum-button-primary" to="/forum/new">Bắt đầu chia sẻ</Link>
          </section>
        ) : (
          <>
            <ForumHeader title={title} />
            <div className="forum-home-layout">
              <main className="forum-main-column">
                {!routeCategoryId && !routeCourseId && location.pathname !== '/forum/search' && (
                  <section className="forum-panel forum-categories-panel">
                    <div className="forum-section-heading forum-heading-with-link">
                      <div>
                        <span className="forum-section-kicker">TÌM KHÔNG GIAN PHÙ HỢP</span>
                        <h2>Chuyên mục học tập</h2>
                      </div>
                      <Link to="/forum/categories">Xem tất cả <span aria-hidden="true">→</span></Link>
                    </div>
                    <ForumCategories categories={categories.slice(0, 4)} onSelect={selectCategory} />
                  </section>
                )}

                <section className="forum-panel forum-topics-panel">
                  <nav className="forum-topic-tabs" aria-label="Lọc loại chủ đề">
                    {TOPIC_TYPES.map((item) => {
                      const params = new URLSearchParams(location.search)
                      if (item.value) params.set('type', item.value)
                      else params.delete('type')
                      params.delete('page')
                      return (
                        <Link
                          key={item.value || 'all'}
                          className={type === item.value ? 'is-active' : ''}
                          to={`${location.pathname}${params.toString() ? `?${params.toString()}` : ''}`}
                        >
                          {item.label}
                        </Link>
                      )
                    })}
                    <Link className={isCategoryIndex ? 'is-active' : ''} to="/forum/categories">Danh mục</Link>
                  </nav>
                  <div className="forum-topics-body">
                    <ForumFilters
                      q={q}
                      type={type}
                      categoryId={activeCategoryId}
                      facultyId={activeFacultyId}
                      majorId={activeMajorId}
                      sort={sort}
                      categories={categories}
                      faculties={faculties}
                      majors={majors}
                      onChange={handleFilterChange}
                      onSearch={handleSearch}
                    />
                    <div className="forum-section-heading forum-topics-heading">
                      <div>
                        <span className="forum-section-kicker">{location.pathname === '/forum/search' ? 'TÌM KIẾM' : 'CỘNG ĐỒNG CMC'}</span>
                        <h2>{location.pathname === '/forum/search' ? 'Kết quả tìm kiếm' : 'Chủ đề mới nhất'}</h2>
                      </div>
                      <span className="forum-result-count">{totalElements} chủ đề</span>
                    </div>
                    {error && <div className="forum-alert forum-alert-error" role="alert">{error}</div>}
                    {notice && <div className="forum-alert forum-alert-success" role="status">{notice}</div>}
                    {loading ? (
                      <div className="forum-loading" role="status"><span className="forum-spinner" /> Đang tải chủ đề...</div>
                    ) : topics.length ? (
                      <div className="forum-topic-list">
                        {topics.map((topic) => (
                          <TopicCard
                            key={topic.id}
                            topic={topic}
                            saved={savedIds.has(topic.id)}
                            onBookmark={handleBookmark}
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="forum-empty-state">
                        <span className="forum-empty-icon"><BookOpenIcon size={25} /></span>
                        <h3>Chưa có chủ đề phù hợp</h3>
                        <p>Thử đổi từ khóa hoặc bộ lọc, hoặc tạo chủ đề đầu tiên để khởi động cuộc trò chuyện.</p>
                        <Link className="forum-button forum-button-primary" to="/forum/new">Tạo chủ đề</Link>
                      </div>
                    )}
                    <div className="forum-pagination">
                      <button type="button" disabled={page <= 0 || loading} onClick={() => setPage((value) => value - 1)}>←</button>
                      <span>Trang {totalPages ? page + 1 : 0} / {totalPages || 0}</span>
                      <button type="button" disabled={page + 1 >= totalPages || loading} onClick={() => setPage((value) => value + 1)}>→</button>
                    </div>
                  </div>
                </section>
              </main>
              <ForumSidebar categories={categories} topics={topics} onCategorySelect={selectCategory} />
            </div>
          </>
        )}
      </div>
    </div>
  )
}
